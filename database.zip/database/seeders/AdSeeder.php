<?php

namespace Database\Seeders;

use App\Models\Ad;
use App\Models\Category;
use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Str;

class AdSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $user = User::first();


        $categories = Category::all();

        if ($categories->isEmpty()) {
            $this->command->warn('❗ مفيش فئات مضافة. لازم تضيف كاتيجوري الأول.');
            return;
        }

        $ads = [
            ['title' => 'ذبائح بلدي طازجة', 'price' => 2500],
            ['title' => 'كفتة مشوية على الفحم', 'price' => 180],
            ['title' => 'دجاج بلدي مذبوح', 'price' => 300],
        ];

        foreach ($ads as $index => $ad) {
            $category = $categories->random();

            Ad::create([
                'user_id' => 2,
                'category_id' => $category->id,
                'title' => $ad['title'],
                'slug' => Str::slug($ad['title']) . '-' . ($index + 1),
                'thumbnail_path' => 'icons/ads/default.png',
                'description' => 'إعلان خاص بـ ' . $ad['title'],
                'price' => $ad['price'],
                'quantity_available' => 10,
                'quantity_sold' => 0,
                'weight' => 2.5,
                'rating' => 4.8,
                'views_count' => 100,
                'reviews_count' => 5,
                'status' => 'active',
                'approved_at' => now(),
                'expires_at' => now()->addDays(30),
            ]);
        }

        $this->command->info('✅ تم إنشاء الإعلانات بنجاح');
    }
}
