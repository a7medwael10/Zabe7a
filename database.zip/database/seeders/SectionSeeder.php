<?php

namespace Database\Seeders;

use App\Models\Section;
use Illuminate\Database\Seeder;

class SectionSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $sections = [
            [
                'name' => 'ذبائح',
                'slug' => 'zbaih',
                'icon' => 'icons/zbah.png',
                'description' => 'قسم الذبائح الطازجة',
            ],
            [
                'name' => 'لحوم',
                'slug' => 'lhoom',
                'icon' => 'icons/lahm.png',
                'description' => 'قسم اللحوم المتنوعة',
            ],
            [
                'name' => 'مشويات',
                'slug' => 'mshwyat',
                'icon' => 'icons/mshwyat.png',
                'description' => 'قسم المشويات الطازجة',
            ],
            [
                'name' => 'الدواجن',
                'slug' => 'aldwajn',
                'icon' => 'icons/dwagn.png',
            ],
        ];

        foreach ($sections as $section) {
            Section::create([
                'name' => $section['name'],
                'slug' => $section['slug'],
                'icon' => $section['icon'],
            ]);
        }

        $this->command->info('✅ تم إنشاء الأقسام بنجاح');
    }
}
