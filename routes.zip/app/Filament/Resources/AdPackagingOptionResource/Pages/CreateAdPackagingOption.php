<?php

namespace App\Filament\Resources\AdPackagingOptionResource\Pages;

use App\Filament\Resources\AdPackagingOptionResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateAdPackagingOption extends CreateRecord
{
    protected static string $resource = AdPackagingOptionResource::class;
}
