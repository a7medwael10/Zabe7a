<?php

use Illuminate\Support\Facades\Route;

Livewire::setScriptRoute(function($handle) {
    return Route::get('/livewire/livewire.js', $handle);
});

Livewire::setUpdateRoute(function($handle) {
    return Route::get('/livewire/update', $handle);
});
